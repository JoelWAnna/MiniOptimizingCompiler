package mil;


/** Represents a parameter inside a function definition.
 */
public class ParamTemp extends Temp {

    /** Default constructor.
     */
    public ParamTemp(String id) {
        super(id);
    }
}
