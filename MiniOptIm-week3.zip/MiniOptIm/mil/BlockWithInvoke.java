package mil;

public class BlockWithInvoke extends Block {

    /** Default constructor.
     */
    public BlockWithInvoke(Code code) {
        super(code);
    }
}
