package mil;

public class BlockWithEnter extends Block {

    /** Default constructor.
     */
    public BlockWithEnter(Code code) {
        super(code);
    }
}
