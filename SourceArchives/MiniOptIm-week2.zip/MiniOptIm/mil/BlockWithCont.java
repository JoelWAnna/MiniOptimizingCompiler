package mil;

public class BlockWithCont extends Block {

    /** Default constructor.
     */
    public BlockWithCont(Code code) {
        super(code);
    }
}
